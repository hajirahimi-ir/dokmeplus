<?php
/**
 * Plugin Name: Dokme Plus
 * Description: ساخت دکمه‌های قابل تنظیم مانند لینک، تماس، پیامک و...
 * Version: 1.3
 * Author: hajirahimi.ir
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */


if ( ! defined( 'ABSPATH' ) ) exit;

add_action('admin_menu', function() {
    add_menu_page('دکمه پلاس', 'دکمه پلاس', 'manage_options', 'dokmeplus', 'dokmeplus_list_page', 'dashicons-button');
    add_submenu_page('dokmeplus', 'افزودن دکمه', 'افزودن دکمه', 'manage_options', 'dokmeplus_add', 'dokmeplus_form_page');
    add_submenu_page('dokmeplus', 'درباره توسعه‌دهنده', '<span style="color:red;">درباره توسعه‌دهنده</span>', 'manage_options', 'dokmeplus_about', 'dokmeplus_about_page');
});

add_action('admin_init', function() {
    if (isset($_GET['delete_id'])) {
        $id = sanitize_text_field($_GET['delete_id']);
        $all = get_option('dokmeplus_buttons', []);
        unset($all[$id]);
        update_option('dokmeplus_buttons', $all);
        wp_redirect(admin_url('admin.php?page=dokmeplus'));
        exit;
    }
});

add_shortcode('dokmeplus', function($atts) {
    $atts = shortcode_atts(['id' => ''], $atts);
    $buttons = get_option('dokmeplus_buttons', []);
    $id = $atts['id'];
    if (!isset($buttons[$id])) return '';

    $b = $buttons[$id];
    $style = 'background-color:' . esc_attr($b['color']) . '; font-size:' . intval($b['size']) . 'px; padding:10px 20px; color:white; border:none; border-radius:5px; cursor:pointer;';

    switch ($b['action']) {
        case 'link':
            return '<a href="' . esc_url($b['link']) . '" target="_blank"><button style="' . $style . '">' . esc_html($b['text']) . '</button></a>';
        case 'copy':
            return '<button style="' . $style . '" onclick="navigator.clipboard.writeText(\'' . esc_js($b['copy_text']) . '\'); alert(\'متن کپی شد!\');">' . esc_html($b['text']) . '</button>';
        case 'send':
            return '<button style="' . $style . '" onclick="if(navigator.share){navigator.share({text: \'' . esc_js($b['send_text']) . '\'});}else{alert(\'مرورگر شما پشتیبانی نمی‌کند.\');}">' . esc_html($b['text']) . '</button>';
        case 'call':
            return '<a href="tel:' . esc_attr($b['call_number']) . '"><button style="' . $style . '">' . esc_html($b['text']) . '</button></a>';
        case 'sms':
            return '<a href="sms:' . esc_attr($b['sms_number']) . '?body=' . urlencode($b['sms_message']) . '"><button style="' . $style . '">' . esc_html($b['text']) . '</button></a>';
        default:
            return '<button style="' . $style . '">' . esc_html($b['text']) . '</button>';
    }
});

function dokmeplus_form_page() {
    include plugin_dir_path(__FILE__) . 'form.php';
}

function dokmeplus_list_page() {
    include plugin_dir_path(__FILE__) . 'list.php';
}

function dokmeplus_about_page() {
    echo '<div class="wrap">';
    echo '<h1>درباره توسعه‌دهنده</h1>';
    echo '<p>این افزونه با <span style="color:red;">❤</span> توسط <a href="https://hajirahimi.ir" target="_blank">حسین حاجی رحیمی</a> ساخته شده است.</p>';
    echo '</div>';
}
