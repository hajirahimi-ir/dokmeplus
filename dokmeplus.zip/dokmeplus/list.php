<div class="wrap">
<h1>دکمه‌ها</h1>
<a href="<?php echo admin_url('admin.php?page=dokmeplus_add') ?>" class="button-primary">افزودن دکمه</a>
<table class="widefat">
<thead><tr><th>عنوان</th><th>کد کوتاه</th><th>عملیات</th></tr></thead>
<tbody>
<?php
$all = get_option('dokmeplus_buttons', []);
if ($all) {
    foreach ($all as $id => $btn) {
        echo '<tr>';
        echo '<td>' . esc_html($btn['title']) . '</td>';
        echo '<td>[dokmeplus id="' . esc_attr($id) . '"]</td>';
        echo '<td><a href="' . admin_url('admin.php?page=dokmeplus_add&edit_id=' . $id) . '">ویرایش</a> | <a href="' . admin_url('admin.php?page=dokmeplus&delete_id=' . $id) . '" onclick="return confirm(\'حذف شود؟\')">حذف</a></td>';
        echo '</tr>';
    }
} else {
    echo '<tr><td colspan="3">هیچ دکمه‌ای وجود ندارد.</td></tr>';
}
?>
</tbody>
</table>
</div>